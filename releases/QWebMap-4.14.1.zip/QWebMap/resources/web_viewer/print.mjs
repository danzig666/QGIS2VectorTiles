// Print on one A4 landscape page: the map at its printed size on the left,
// the title, date and a legend of what is drawn in the printed area (or the
// parcel report) on the right. The map is resized to its print size and
// redrawn before the browser prints (a CSS-stretched map canvas printed
// distorted or clipped); a long legend continues on the next page between
// entries, never inside one. The map prints at a map scale (M 1:500): the
// chosen one, or the screen's rounded to a standard scale; the sheet says it.
// A parcel report prints zoomed on the parcel (focusView), down to 1:100.
import { el } from "./icons.mjs";
import { t, formatNumber } from "./i18n.mjs";

const SHEET = "q2vt-print-sheet";
const EARTH = 40075016.686;      // m, equator (Web Mercator)
const PAPER_PX = 0.0254 / 96;    // m, one CSS pixel on paper at 100 %
export const PRINT_SCALES = [100, 200, 250, 500, 1000, 1500, 2000, 2500, 4000, 5000, 10000, 20000, 25000, 50000, 100000, 200000, 500000];

// Scale denominator of the map at a zoom (512 px tiles) and latitude, on paper.
export function scaleAt(zoom, lat) {
  return EARTH * Math.cos(lat * Math.PI / 180) / (512 * 2 ** zoom) / PAPER_PX;
}

export function zoomFor(scale, lat) {
  return Math.log2(EARTH * Math.cos(lat * Math.PI / 180) / (512 * scale * PAPER_PX));
}

// A parcel printed on its own: the margin (share of the map on each side)
// left around it, so the neighbouring parcels' edges show, no more.
const FOCUS_MARGIN = 0.12;

// The closest standard scale showing [west, south, east, north] (WGS 84)
// whole on a map of width x height CSS px, with FOCUS_MARGIN around it, and
// its centre; null for an empty box.
export function focusView(bounds, width, height) {
  const [w, s, e, n] = bounds || [];
  if (![w, s, e, n].every(Number.isFinite) || !(e > w) || !(n > s) || !(width > 0) || !(height > 0)) return null;
  const merc = (lat) => Math.log(Math.tan(Math.PI / 4 + (lat * Math.PI) / 360));
  const lat = (s + n) / 2;
  const dx = (e - w) / 360, dy = (merc(n) - merc(s)) / (2 * Math.PI);  // world fractions
  const room = 1 - 2 * FOCUS_MARGIN;
  const zoom = Math.log2(Math.min((width * room) / (dx * 512), (height * room) / (dy * 512)));
  const fit = scaleAt(zoom, lat);  // the largest scale with the whole parcel on paper
  const scale = PRINT_SCALES.find((candidate) => candidate >= fit) || PRINT_SCALES[PRINT_SCALES.length - 1];
  const centerLat = (Math.atan(Math.sinh((merc(s) + merc(n)) / 2)) * 180) / Math.PI;
  return { center: { lng: (w + e) / 2, lat: centerLat }, scale };
}

// The standard scale nearest to a scale (on a log scale).
export function standardScale(scale) {
  return PRINT_SCALES.reduce((best, s) => (Math.abs(Math.log(s / scale)) < Math.abs(Math.log(best / scale)) ? s : best));
}

function idle(map, timeout = 6000) {
  return new Promise((resolve) => {
    const timer = setTimeout(resolve, timeout);
    map.once("idle", () => { clearTimeout(timer); resolve(); });
    map.triggerRepaint();
  });
}

export class Printer {
  // content(mode) -> the sheet's body for "map" (legend) or "parcel" (report).
  constructor({ map, manifest, content }) {
    Object.assign(this, { map, manifest, content });
    this.active = false;
    this.scale = 0;  // 0: the screen's scale, rounded to a standard scale
    // Ctrl+P (the browser's own print): the same layout, without waiting.
    this.onBefore = () => { if (!this.active) this.prepare("map"); };
    this.onAfter = () => this.restore();
    window.addEventListener("beforeprint", this.onBefore);
    window.addEventListener("afterprint", this.onAfter);
  }

  sheet() {
    let sheet = document.getElementById(SHEET);
    if (!sheet) {
      sheet = el("section");
      sheet.id = SHEET;
      document.getElementById("q2vt-app").append(sheet);
    }
    return sheet;
  }

  // ``focus`` ([west, south, east, north], a parcel): printed zoomed on it
  // (unless a print scale was chosen), else the screen's view.
  prepare(mode, focus = null) {
    this.active = true;
    this.view = { center: this.map.getCenter(), zoom: this.map.getZoom(), bearing: this.map.getBearing() };
    document.body.classList.add("q2vt-printing", `q2vt-printing-${mode}`);
    this.map.resize();
    const canvas = this.map.getContainer();
    const fitted = focus ? focusView(focus, canvas.clientWidth, canvas.clientHeight) : null;
    const center = fitted && !this.scale ? fitted.center : this.view.center;
    const lat = center.lat;
    const wanted = this.scale || (fitted ? fitted.scale : standardScale(scaleAt(this.view.zoom, lat)));
    // The centre (the parcel's, or the screen's), at the scale on paper.
    this.map.jumpTo({ ...this.view, center, zoom: zoomFor(wanted, lat) });
    const actual = scaleAt(this.map.getZoom(), lat);  // the map's zoom limits may not reach it
    this.printScale = Math.abs(actual / wanted - 1) < 0.005 ? wanted : Math.round(actual);
    this.fill(mode);
  }

  fill(mode) {
    const head = el("header", "q2vt-print-head");
    head.append(el("h1", "", this.manifest.title || ""));
    if (this.printScale) head.append(el("p", "q2vt-print-scale", t("print.scale", { scale: formatNumber(this.printScale, 0) })));
    const date = new Date().toLocaleString(document.documentElement.lang || undefined);
    head.append(el("p", "", [date, this.manifest.attribution].filter(Boolean).join(" — ")));
    const body = this.content(mode) || el("div");
    body.classList.add("q2vt-print-body");
    this.sheet().replaceChildren(head, body);
  }

  async print(mode = "map", focus = null) {
    if (this.active) return;
    this.prepare(mode, focus);
    await idle(this.map);
    this.fill(mode);  // the legend of what the printed map draws
    window.print();
  }

  restore() {
    if (!this.active) return;
    this.active = false;
    document.body.classList.remove("q2vt-printing", "q2vt-printing-map", "q2vt-printing-parcel");
    const sheet = document.getElementById(SHEET);
    if (sheet) sheet.replaceChildren();
    this.map.resize();
    if (this.view) this.map.jumpTo(this.view);
  }

  destroy() {
    window.removeEventListener("beforeprint", this.onBefore);
    window.removeEventListener("afterprint", this.onAfter);
  }
}
