// QWebMap web map viewer (release entry point).
//
// Loads manifest.json (relative to this page), validates it (schema 1,
// vector-only), binds the vector tile transport (PMTiles over HTTP ranges or
// XYZ MVT), loads the exported MapLibre style unchanged except for transport
// URLs, creates the map and the existing visible-polygon label helper, then
// mounts the interactive controls described by the manifest.
import * as maplibregl from "./maplibre-gl.mjs";
import { enableVisibleLabels } from "./visible_labels.mjs";
import { RASTER_TILE_TYPES, ViewerError, bindStyle, checkRelative, openArchives, resolveUrl } from "./transport.mjs";
import { loadLocale, t } from "./i18n.mjs";
import { fetchChecked, showError, state as diagnostics, warn } from "./diagnostics.mjs";

export const EXPECTED_MAPLIBRE = "6.11.2";
const RELEASE_ID = /^r-[0-9]{8}T[0-9]{6}Z-[0-9a-f]{8}$/;

function validateManifest(manifest) {
  if (!manifest || typeof manifest !== "object") throw new ViewerError("Q2VT_PUB_MANIFEST", "manifest is not an object");
  if (manifest.schemaVersion !== 1) {
    throw new ViewerError(manifest.schemaVersion > 1 ? "Q2VT_PUB_SCHEMA_UNSUPPORTED" : "Q2VT_PUB_MANIFEST",
      `manifest schemaVersion ${manifest.schemaVersion}`);
  }
  if (manifest.vectorOnly !== true) throw new ViewerError("Q2VT_PUB_RASTER_SOURCE", "manifest is not vector-only");
  if (!RELEASE_ID.test(manifest.releaseId || "")) throw new ViewerError("Q2VT_PUB_MANIFEST", "bad releaseId");
  if (!Array.isArray(manifest.sources) || !manifest.sources.length) throw new ViewerError("Q2VT_PUB_MANIFEST", "no sources");
  for (const [index, source] of manifest.sources.entries()) {
    // The map data is MVT; QGIS raster layers have their own image archives.
    const raster = source.role === "raster";
    if (index === 0 && raster) throw new ViewerError("Q2VT_PUB_NOT_MVT", "the first source must be the vector map");
    if (raster ? !RASTER_TILE_TYPES.includes(source.tileType) || source.kind !== "pmtiles"
        || !String(source.id).startsWith("q2vt_raster_") : source.tileType !== "mvt") {
      throw new ViewerError("Q2VT_PUB_NOT_MVT", `source ${source.id} tileType ${source.tileType}`);
    }
    if (!["pmtiles", "xyz"].includes(source.kind)) throw new ViewerError("Q2VT_PUB_MANIFEST", `source kind ${source.kind}`);
    checkRelative(source.href, "source");
  }
  checkRelative(manifest.style, "style");
  for (const key of ["groups", "layers", "rules", "components"]) {
    if (!Array.isArray(manifest[key])) throw new ViewerError("Q2VT_PUB_MANIFEST", `${key} missing`);
  }
  const view = manifest.view || {};
  if (!Array.isArray(view.center) || view.center.length !== 2 || typeof view.zoom !== "number") {
    throw new ViewerError("Q2VT_PUB_MANIFEST", "bad view");
  }
  return manifest;
}

function webglAvailable() {
  try {
    const canvas = document.createElement("canvas");
    return !!(canvas.getContext("webgl2") || canvas.getContext("webgl"));
  } catch {
    return false;
  }
}

function setText(id, text) {
  const node = document.getElementById(id);
  if (node) node.textContent = text;
}

// Accent colour, logo and subtitle from the manifest (validated values only).
function applyBranding(manifest, pageUrl) {
  const accent = manifest.ui && manifest.ui.accent;
  if (typeof accent === "string" && /^#[0-9a-fA-F]{6}$/.test(accent)) {
    document.documentElement.style.setProperty("--q2vt-accent", accent);
  }
  const logo = document.getElementById("q2vt-logo");
  if (logo && typeof manifest.logo === "string" && /^assets\/logo\.(png|jpe?g|webp)$/.test(manifest.logo)) {
    logo.src = new URL(manifest.logo, pageUrl).href;
    logo.hidden = false;
  }
  const subtitle = document.getElementById("q2vt-subtitle");
  if (subtitle && manifest.description) {
    subtitle.textContent = manifest.description.split("\n")[0].slice(0, 140);
    subtitle.hidden = false;
    const full = document.getElementById("q2vt-description");
    if (full && full.textContent.trim() === subtitle.textContent.trim()) full.hidden = true;
  }
}

// Opened through the publication's stable entry: show that (short, stable)
// address again. Relative URLs keep resolving in the release (<base>); the
// release's own address stays known for "this version" links.
function showEntryAddress(releasePage) {
  let entry = null;
  try {
    entry = JSON.parse(sessionStorage.getItem("q2vt:entry") || "null");
    sessionStorage.removeItem("q2vt:entry");
  } catch { return; }
  if (!entry || entry.release !== location.pathname || typeof entry.entry !== "string"
      || !entry.entry.startsWith("/") || entry.entry.startsWith("//")) return;
  const base = document.createElement("base");
  base.href = releasePage.href;
  document.head.prepend(base);
  history.replaceState(history.state, "", entry.entry + location.search + location.hash);
}

async function start() {
  const releasePage = new URL(location.href);
  const pageUrl = new URL(".", releasePage);
  showEntryAddress(releasePage);
  const assetsUrl = new URL("./", import.meta.url);  // locales, legend code, workers
  const manifestUrl = new URL("manifest.json", pageUrl).href;
  const viewer = (window.q2vtViewer = { ready: false, diagnostics, maplibreVersion: maplibregl.getVersion(),
    releaseUrl: releasePage.href });
  let manifest;
  try {
    manifest = validateManifest(await fetchChecked(manifestUrl));
  } catch (error) {
    await loadLocale(navigator.language.slice(0, 2), assetsUrl).catch(() => {});
    if (!error.code || error.code === "Q2VT_PUB_FETCH") error.code = "Q2VT_PUB_MANIFEST";
    showError(error);
    return;
  }
  await loadLocale(manifest.locale || "en", assetsUrl).catch(() => {});
  document.title = manifest.title || document.title;
  setText("q2vt-title", manifest.title || "");
  setText("q2vt-description", manifest.description || "");
  setText("q2vt-release", `${t("app.release")}: ${manifest.releaseId}`);
  setText("q2vt-loading-text", t("app.loading"));
  applyBranding(manifest, pageUrl);
  viewer.manifest = manifest;
  if (maplibregl.getVersion() !== EXPECTED_MAPLIBRE) {
    warn("error.labels", `MapLibre ${maplibregl.getVersion()} is not the tested ${EXPECTED_MAPLIBRE}`);
  }
  try {
    if (!webglAvailable()) throw new ViewerError("Q2VT_PUB_WEBGL", "WebGL unavailable");
    viewer.archives = await openArchives(manifest, manifestUrl, maplibregl);
    const styleUrl = resolveUrl(manifest.style, manifestUrl);
    const style = bindStyle(await fetchChecked(styleUrl), manifest, manifestUrl, styleUrl);
    viewer.style = style;
    const view = manifest.view;
    const map = new maplibregl.Map({
      container: "q2vt-map",
      style,
      center: view.center,
      zoom: view.zoom,
      minZoom: view.minZoom ?? 0,
      maxZoom: view.maxZoom ?? 22,
      bearing: 0,
      pitch: 0,
      maxPitch: 0,
      dragRotate: false,
      pitchWithRotate: false,
      touchPitch: false,
      attributionControl: false,
      renderWorldCopies: false,
      canvasContextAttributes: { preserveDrawingBuffer: new URLSearchParams(location.search).has("print") },
    });
    map.touchZoomRotate.disableRotation();
    viewer.map = map;
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");
    map.addControl(new maplibregl.FullscreenControl(), "top-right");
    if (window.isSecureContext && navigator.geolocation) {
      map.addControl(new maplibregl.GeolocateControl({ positionOptions: { enableHighAccuracy: true },
        trackUserLocation: false, showAccuracyCircle: true }), "top-right");
    }
    map.on("error", (event) => {
      const message = String(event && event.error && event.error.message || event);
      diagnostics.warnings.push({ key: "map", detail: message.slice(0, 500) });
      if (/sprite/i.test(message)) warn("error.sprite", message);
    });
    await new Promise((resolve) => map.once("load", resolve));
    document.body.classList.add("q2vt-loaded");
    const sourceId = manifest.sources[0].id;
    // Layers whose every feature keeps its label (shrunk where it does not fit).
    const always = new Set();
    for (const layer of manifest.layers || []) {
      if (!layer.labelAlways) continue;
      for (const component of manifest.components || []) {
        if (component.layerId === layer.id) for (const id of component.styleLayerIds || []) always.add(id);
      }
    }
    viewer.labels = enableVisibleLabels(map, maplibregl, sourceId, {
      always,
      onUnsupported: (reason) => warn("error.labels", reason),
    });
    // Interactive controls (layer tree, legend, popups, search, filters,
    // permalinks, tools) live in their own modules.
    const controls = await import("./controls.mjs").catch((error) => {
      diagnostics.warnings.push({ key: "controls", detail: String(error).slice(0, 500) });
      return null;
    });
    if (controls) viewer.controls = await controls.mount({ map, manifest, manifestUrl, pageUrl, assetsUrl, maplibregl, viewer });
    viewer.ready = true;
    document.dispatchEvent(new CustomEvent("q2vt:ready"));
  } catch (error) {
    showError(error);
  }
}

start();
